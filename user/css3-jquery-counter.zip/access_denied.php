<!DOCTYPE HTML>
<html dir="ltr" lang="en-US">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="20script.ir"/>
	<title>CSS3 + jQuery Counter 20script</title>

	<!-- CSS -->
	<link rel="stylesheet" href="style.css" type="text/css" />

	<!-- jQuery -->
	<script type="text/javascript" src="js/jquery-1.7.1.min.js"></script>

	<!-- Countdown -->
	<script type="text/javascript" src="js/jquery.countdown.js"></script>
	<script type="text/javascript" src="js/script.js"></script>

	</head>

	<body>

		<div id="launching_in">
			Launching in:
		</div>

		<div id="counter">

		</div>

		<div id="text">
			<div class="days">DAYS</div>
			<div class="hours">HOURS</div>
			<div class="minutes">MINUTES</div>
			<div class="seconds">SECONDS</div>
		</div>

		<div id="footer">
			CSS3 + jQuery Counter by <a href="http://20script.ir">20script</a> - Follow me on <a href="http://www.facebook.com/20script">Facebook</a> and <a href="http://twitter.com/20script">Twitter</a>!
		</div>

	</body>
</html>
